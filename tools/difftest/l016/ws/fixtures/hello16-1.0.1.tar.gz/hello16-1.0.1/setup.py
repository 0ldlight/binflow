from setuptools import setup
setup(name='hello16', version=pkg_dir.split('-')[-1], py_modules=[])
